<?php
// Paperplane _blankTheme - template per index.
get_header();
echo '<h1>Please set a static page as homepage in Settings - Reading</h1>';
get_footer(); ?>
