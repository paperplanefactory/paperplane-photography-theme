<div id="infscr-loading" class="bg-5 txt-1">
  <div class="infinite-scroll-request">
    <p>
      Loading more contents...
    </p>
  </div>
  <div class="infinite-scroll-last">
    <p>
      No more contents.
    </p>
  </div>
  <div class="infinite-scroll-error">
    <p>
      Ooops...
    </p>
  </div>
</div>
<!-- qui aggiungo la paginazione classica di WP che verrà poi nascosta -->
<div class="navigation">
<div class="alignleft"><?php previous_posts_link(); ?></div>
<div class="alignright nav-next"><?php next_posts_link(); ?></div>
</div>
