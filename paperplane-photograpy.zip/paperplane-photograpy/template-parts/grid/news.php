<div class="news-item grid-item-infinite">
  <h2 class="as-h4"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
  <div class="cta-1"><?php the_time( get_option( 'date_format' ) ); ?></div>
</div>
